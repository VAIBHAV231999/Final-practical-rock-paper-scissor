package com.example.mysqliteexperiment

data class Student(val name:String?=null,val score:String?=null){

}
